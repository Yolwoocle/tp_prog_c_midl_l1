#include <stdio.h>
#include <stdlib.h>
#include "image.h"

int main(void) {
    im_lire("chien.pgm");

    return 0;
}